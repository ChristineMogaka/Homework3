/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING   * *
 * * CSCE 1040 –Homework 3              * *
 * * NAME:CHRISTINE MOGAKA              * *
 * * EUID:cm0981                        * *
 * * DATE:06/14/2021                    * *
 * * EMAIL:ChristineMogaka@my.unt.edu   * *
 * ***************************************/

#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
#include <ctime>

using namespace std;

class Loan
{
private:
    string loan_id;
    string movie_id;
    string customer_id;
    string due_date;
    string statuses[4] = {"Overdue", "Canceled", "Complete", "Active"};
    unsigned int status;
    float amount;

public:
    Loan(string movie_id, string customer_id, string date_due, float amount, string loan_id);
    ~Loan();

    // accesor methods
    string getLoanID();
    string getCustomerId();
    string getDueDate();
    string getMovieId();
    unsigned int getStatus();
    float getAmount();

    //mutator methods
    void setAmount(float amount);
    void setLoanID();
    void setCustomerId();
    void setDueDate();
    void setMovieId();
    void setStatus();

    //utility functions
    void printDetails();
    void edit();
    string getStr(string prompt);
};
