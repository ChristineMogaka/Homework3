/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * NAME:CHRISTINE MOGAKA		* *
 * * EUID:cm0981			* *
 * * DATE:06/14/2021			* *
 * * EMAIL:ChristineMogaka@unt.edu      * *
 * * CSCE 1040 Homework 3		* *
 * ***************************************/
#include "Movie.h"
#include <cmath>

// initialize new object
Movie::Movie(string id, string title, string date, string duration, float cost, float r_cost, unsigned int copies)
{
    this->cost = cost;
    this->duration = duration;
    this->r_cost = r_cost;
    this->title = title;
    this->date = date;
    this->copies = copies;
}

Movie::Movie()
{
    this->setTitle();
    this->setId();
    this->setCost();
    this->setR_cost();
    this->setDuration();
    this->setDate();
    this->setRating();
    this->addCopies();
}
Movie::~Movie() {}

// Accessors Methods
unsigned int Movie::getCopies()
{
    return this->copies;
}
string Movie::getId()
{
    return id;
}
string Movie::getTitle()
{
    return this->title;
}
int Movie::getRating()
{
    return this->rating;
}
string Movie::getDate()
{
    return this->date;
}
float Movie::getCost()
{
    return this->cost;
}
float Movie::getR_cost()
{
    return this->r_cost;
}
string Movie::getDuration()
{
    return this->duration;
}

//Mutators Methods
void Movie::setId()
{
    string ID = this->getStr("Movie ID (8 characters Max)");
    this->id = ID;
};
void Movie::setTitle()
{
    string TITLE = this->getStr("Movie Title (40 characters Max)");
    this->title = TITLE;
};
void Movie::setRating()
{
    int temp;
    cout << "Enter Movie Rating (0-Min 5-Max): ";
    cin >> temp;
    if (temp <= 0)
    {
        temp = 0;
    }
    if (temp >= 5)
    {
        temp = 5;
    }
    this->rating = (int)temp;
};
void Movie::setCost()
{
    float temp;
    cout << "Enter Movie Cost: ";
    cin >> temp;
    this->cost = round(temp);
};
void Movie::setR_cost()
{
    float temp;
    cout << "Enter Movie Replacement Cost: ";
    cin >> temp;
    this->r_cost = round(temp);
};
void Movie::addCopies()
{
    unsigned int temp;
    cout << "Enter No Number of Copies to Add: ";
    cin >> temp;
    this->copies += temp;
};
void Movie::setDuration()
{
    string temp = this->getStr("Duration (HH:MM)");
    this->duration = temp.substr(0, 5);
};
void Movie::setDate()
{
    string temp = this->getStr("Release Date (dd/mm/yyyy)");
    this->date = temp.substr(0, 10);
}

// utitlity functions
void Movie::edit()
{

    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Edit Title                       |\n");
    printf("| 2 : Edit ID                          |\n");
    printf("| 3 : Edit Rating.                     |\n");
    printf("| 4 : Edit Availabe Copies.            |\n");
    printf("| 5 : Edit Cost.                       |\n");
    printf("| 6 : Edit Replacing Cost              |\n");
    printf("| 7 : Edit Duration.                   |\n");
    printf("| 8 : Edit All                         |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
    unsigned int option;
    cin >> option;

    //
    switch (option)
    {
    case 1:
        this->setTitle();
        break;
    case 2:
        this->setId();
        break;
    case 3:
        this->setRating();
        break;
    case 4:
        this->addCopies();
        break;
    case 5:
        this->setCost();
        break;
    case 6:
        this->setR_cost();
        break;
    case 7:
        this->setDuration();
        break;
    case 8:
        this->setTitle();
        this->setId();
        this->setRating();
        this->addCopies();
        this->setCost();
        this->setR_cost();
        break;
    default:
        cout << "Invalid Option Chosen. No changes Made";
        break;
    }
}

//helper function to print details
void Movie::printDetails()
{
    printf("\n");
    printf("+--------------------------------------+\n");
    printf("| Title: %s\n", this->title.c_str());
    printf("| ID: %s\n", this->id.c_str());
    printf("| Release Date: %s\n", this->date.c_str());
    printf("| Duration: %s\n", this->getDuration().c_str());
    printf("| Rating:%d\n", this->getRating());
    printf("| Cost: %.2f\n", this->getCost());
    printf("| Replacing Cost: %.2f\n", this->getR_cost());
    printf("| Available Copies: %d\n", this->getCopies());
    printf("+--------------------------------------+\n");
    printf("\n");
}
// helper function to round-off floats
float Movie::round(float var)
{
    float value = (int)(var * 100 + .5);
    return (float)value / 100;
}

// helper function to prompt and input string
string Movie::getStr(string prompt)
{
    string str;
    printf("Enter %s : ", prompt.c_str());
    cin >> str;
    return str;
}
