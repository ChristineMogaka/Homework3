/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING   * *
 * * CSCE 1040 –HOMEWORK 3              * *
 * * NAME:Christine Mogaka              * *
 * * EUID:cm0981                        * *
 * * DATE:06/14/2021                    * *
 * * EMAIL:ChristinMogaka@my.unt.edu    * *
 * ***************************************/

#include "Movies.h"
#include "Loans.h"
#include "Customers.h"
#include "functions.h"

int main(int argc, char const *argv[])
{
    // initialize pointers to collection class objects to hold data
    Movies *movies = new Movies();
    Loans *loans = new Loans();
    Customers *customers = new Customers();

    bool back = false; // aid in back navigation
    while (true)
    {
        // display prompt menu
        printMenu();
        unsigned int option;
        cin >> option;
        switch (option)
        {
        case 1:
            while (!back)
            {
                // prompt instruction
                printf("+--------------------------------------+\n");
                printf("| Customer Operations                  |\n");
                printf("| 1 : Add Customer Operation           |\n");
                printf("| 2 : Remove Customer Operations       |\n");
                printf("| 3 : List All Customers Operations    |\n");
                printf("| 4 : Search Customer Operations       |\n");
                printf("| 5 : Upadate Customer Operations      |\n");
                printf("| 0 : Go Back                          |\n");
                printf("+--------------------------------------+\n\n");
                cout << "--->";
                unsigned int customer_option;
                cin >> customer_option;
                switch (customer_option)
                {
                case 1:
                    customers->add();
                    break;
                case 2:
                    customers->remove();
                    break;
                case 3:
                    customers->listAll();
                    break;
                case 4:
                    customers->findOne();
                    break;
                case 5:
                    customers->edit();
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    break;
                }
            }
            back = false;
            break;
        case 2:
            while (!back)
            {
                printf("+---------------------------------------+\n");
                printf("| Loans Operations                      |\n");
                printf("| 1 :  Loan A Movie                     |\n");
                printf("| 2 :  Remove Loan Operations           |\n");
                printf("| 3 :  List All Loans Operations        |\n");
                printf("| 4 :  Search Loan Operations           |\n");
                printf("| 5 :  Update Loan                      |\n");
                printf("| 6 :  List Customer Loans              |\n");
                printf("| 7 :  List Movie Loans                 |\n");
                printf("| 8 :  List Canceled Loans              |\n");
                printf("| 9 :  List Overdue Loans               |\n");
                printf("| 10 : List Complete Loans              |\n");
                printf("| 11 : List Active Loans                |\n");
                printf("| 0 :  Go Back                          |\n");
                printf("+---------------------------------------+\n\n");
                cout << "--->";
                unsigned int customer_option;
                cin >> customer_option;
                if (customer_option == 1)
                {
                    // customer id
                    string customer_id;
                    string m_id;
                    float cost;
                    string loan_id;
                    string due_date;

                    cout << "Enter Customer ID: ";
                    cin >> customer_id;

                    Customer customer = customers->search(customer_id);
                    // validate request
                    if ((customer.getId()).length() > 0)
                    {
                        if (customer.getMovieCount() >= 2)
                        {
                            puts("Already Reached Maximum Loan Limit");
                        }
                        else
                        {
                            string m_id;
                            cout << "Enter Movie ID: ";
                            cin >> m_id;

                            Movie movie = movies->findOne(m_id);

                            // validate request
                            if ((movie.getId()).length() > 0)
                            {
                                if (movie.getCopies() < 1)
                                {
                                    puts("All Copies Sold Out");
                                }
                                else
                                {
                                    cost = movie.getCost();
                                    cout << "Enter Due Date: ";
                                    cin >> due_date;
                                    cout << "Enter Loan ID: ";
                                    cin >> loan_id; /* code */
                                    loans->add(m_id, customer_id, due_date, cost, loan_id);
                                    customers->search(customer_id).updateCount();
                                }
                            }
                            else
                            {
                                puts("Movie Does not Exist in Store.");
                            }
                        }
                    }
                    else
                    {
                        puts("Customer Does not Exist.");
                    }
                }
                if (customer_option == 2)
                {
                    loans->remove();
                }
                if (customer_option == 3)
                {
                    loans->listAll();
                }
                if (customer_option == 4)
                {
                    loans->listOne();
                }
                if (customer_option == 5)
                {
                    loans->update();
                }
                if (customer_option == 6)
                {
                    loans->customerLoans();
                }
                if (customer_option == 7)
                {
                    loans->movieLoans();
                }
                if (customer_option == 8)
                {
                    loans->canceledLoans();
                }
                if (customer_option == 9)
                {
                    loans->overDueLoans();
                }
                if (customer_option == 10)
                {
                    loans->completeLoans();
                }
                if (customer_option == 11)
                {
                    loans->activeLoans();
                }
                if (customer_option == 0)
                {
                    back = true;
                }
                else if (customer_option < 1 || customer_option > 11)
                {
                    puts("Invalid Choice");
                    back = false;
                }
            }
            break;
        case 3:
            while (!back)
            {
                printf("+---------------------------------------+\n");
                printf("| Movies Operations                     |\n");
                printf("| 1 : Add Movie Operation               |\n");
                printf("| 2 : Remove Movie Operations           |\n");
                printf("| 3 : List All Movies Operations        |\n");
                printf("| 4 : Search Movie by Name              |\n");
                printf("| 5 : Search Movie by ID                |\n");
                printf("| 6 : Update Movie                      |\n");
                printf("| 0 : Go Back                           |\n");
                printf("+--------------------------------------+\n\n");
                cout << "--->";
                unsigned int customer_option;
                cin >> customer_option;
                switch (customer_option)
                {
                case 1:
                    movies->add();
                    break;
                case 2:
                    movies->remove();
                    break;
                case 3:
                    movies->listAll();
                    break;
                case 4:
                    movies->search();
                    break;
                case 5:
                    movies->listOne();
                    break;
                case 6:
                    movies->update();
                    break;
                case 0:
                    back = true;
                    break;
                default:
                    break;
                }
            }
            back = false;
            break;
        case 0:
            cout << "Thank you for using this program! Have a great day!\n";
            return true;
            break;
        default:
            puts("Invalid selection. Please enter choice 1 - 7.\n");
            break;
        }
    }
}

// print account operation choice
void printMenu()
{
    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Customer Operation               |\n");
    printf("| 2 : Loan Operations                  |\n");
    printf("| 3 : Movies Operations                |\n");
    printf("| 0 : Exit Program                     |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
}

// list accounts present in the banks

