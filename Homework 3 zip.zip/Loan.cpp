/******************************************
 * * COMPUTER SCIENCE AND ENGENEERING   * *
 * * NAME:CHRISTINE MOGAKA		* *
 * * EUID:cm0981         		* *
 * * DATE:06/10/2021                	* *
 * * EMAIL:ChristineMogaka@my.unt.edu	* *
 * * CSCE 1040- HOMEWORK 3              * *
 * ***************************************/
#include "Loan.h"

Loan::Loan(string movie_id, string customer_id, string date_due, float amount, string loan_id)
{
    this->movie_id = movie_id;
    this->customer_id = customer_id;
    this->amount = amount;
    this->due_date = date_due;
    this->loan_id = loan_id;

    // determine if overdue

    tm duetime = {};
    stringstream ss(due_date);
    ss >> get_time(&duetime, "%d/%m/%Y");

    time_t curr_time = time(0);
    time_t due_time = mktime(&duetime);

    int time_diff = difftime(due_time, curr_time);
    if (time_diff < 0)
    {
        this->status = 0;
    }
    else
    {
        this->status = 3;
    }
}

Loan::~Loan() {}
void Loan::printDetails()
{
    puts("\n");
    cout << "Loan ID: " << this->loan_id << endl;
    cout << "Movie ID: " << this->movie_id << endl;
    cout << "Customer ID: " << this->customer_id << endl;
    cout << "Due Date: " << this->due_date << endl;
    cout << "Status: " << this->statuses[this->status] << endl;
    cout << "Amount: " << this->amount << endl;
    puts("\n");
}

string Loan::getLoanID()
{
    return this->loan_id;
}

string Loan::getCustomerId()
{
    return this->customer_id;
}

string Loan::getDueDate()
{
    return this->due_date;
}

string Loan::getMovieId()
{
    return this->movie_id;
}

float Loan::getAmount()
{
    return this->amount;
}
//mutator methods
void Loan::setAmount(float amount)
{
    this->amount = amount;
}

unsigned int Loan::getStatus()
{
    return this->status;
}

void Loan::setLoanID()
{
    this->loan_id = this->getStr("Loan ID");
}

void Loan::setCustomerId()
{
    this->customer_id = this->getStr("Customer ID");
}

void Loan::setDueDate()
{
    this->due_date = this->getStr("Due Date");

    // determine if overdue and adjust status
    tm duetime = {};
    stringstream ss(this->due_date);
    ss >> get_time(&duetime, "%d/%m/%Y");

    time_t curr_time = time(0);
    time_t due_time = mktime(&duetime);

    int time_diff = difftime(due_time, curr_time);
    if (time_diff < 0)
    {
        this->status = 0;
    }
    else
    {
        this->status = 3;
    }
}

void Loan::setMovieId()
{
    this->movie_id = this->getStr("Movie ID");
}

void Loan::setStatus()
{
    unsigned int status;
    cout << "Enter Status (0-Overdue 1-Canceled 2-Complete 3-Active): ";
    cin >> status;
    this->status = status;
}

void Loan::edit()
{

    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Edit Loan ID                     |\n");
    printf("| 2 : Edit Movie ID                    |\n");
    printf("| 3 : Edit Customer ID                 |\n");
    printf("| 4 : Edit Due Date.                   |\n");
    printf("| 5 : Edit Loan Status.                |\n");
    printf("| 5 : Edit All.                        |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
    unsigned int option;
    cin >> option;
    switch (option)
    {
    case 1:
        this->setLoanID();
        break;
    case 2:
        this->setMovieId();
        break;
    case 3:
        this->setCustomerId();
        break;
    case 4:
        this->setDueDate();
        break;
    case 5:
        this->setStatus();
        break;
    case 6:
        this->setLoanID();
        this->setMovieId();
        this->setCustomerId();
        this->setDueDate();
        this->setStatus();
        break;
    default:
        cout << "Invalid Option Chosen. No changes Made";
        break;
    }
}

string Loan::getStr(string prompt)
{
    string str;
    printf("Enter %s : ", prompt.c_str());
    cin >> str;
    return str;
}
