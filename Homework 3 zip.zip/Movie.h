#ifndef MOVIE_H
#define MOVIE_H
#include <string>
#include <ctime>
#include <iostream>

using namespace std;

class Movie
{
private:
    string id;
    string title;
    string date;
    int rating;
    float cost;
    float r_cost;
    string duration;
    unsigned int copies = 0;

public:
    Movie(string id, string title, string date, string duration, float cost, float r_cost, unsigned int copies);
    ~Movie();
    Movie();

    // accessors
    string getId();
    string getTitle();
    int getRating();
    string getDate();
    float getCost();
    float getR_cost();
    string getDuration();
    unsigned int getCopies();

    // Mutators
    void setId();
    void setTitle();
    void setRating();
    void setDate();
    void setCost();
    void setR_cost();
    void setDuration();
    void addCopies();

    // Utility functions
    void edit();
    float round(float var);
    string getStr(string prompt);
    void printDetails();
};
#endif
