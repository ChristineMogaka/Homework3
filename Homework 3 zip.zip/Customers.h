/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1040 –Homework 3		* *
 * * NAME:Christine Mogaka 		* *
 * * EUID:cm0981			* *
 * * DATE:06/14/2021			* *
 * * EMAIL:ChristineMogaka@my.unt.edu   * *						* *
 * ***************************************/
#include "Customer.h"
#include <vector>
#include <algorithm>
class Customers
{
private:
    vector<Customer> customers;

public:
    unsigned int count;
    void add();
    void remove();
    void edit();
    void findOne();
    void listAll();
    Customer search(string id);
};
