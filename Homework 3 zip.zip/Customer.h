/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING   * *
 * * CSCE 1040 –Homework 3              * *
 * * NAME:CHRISTINE MOGAKA              * *
 * * EUID:cm0981                        * *
 * * DATE:06/14/2021                    * *
 * * EMAIL:ChristineMogaka@my.unt.edu   * *
 * ***************************************/
#include <iostream>
#include <string>

using namespace std;

class Customer
{
private:
    string ID;
    string card_no;
    string name;
    string card_exp;
    string card_key;
    unsigned int movie_count;

public:
    Customer();
    Customer(string dummy);
    ~Customer();
    void printDetails();
    void edit();

    string getStr(string prompt, unsigned int max, unsigned int min, unsigned short len);
    string getId();
    string getCardNo();
    string getName();
    unsigned int getMovieCount();
    string getCardKey();
    string getCardExp();

    void setId();
    void setCardNo();
    void setName();
    void setMovieCount();
    void setCardKey();
    void setCardExp();
    void updateCount();
};
