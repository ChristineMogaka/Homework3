/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1040 –HOMEWORK 3 		* *
 * * NAME:Christine Mogaka       	* *
 * * EUID:cm0981			* *
 * * DATE:06/14/2021                    * *								* *
 * * EMAIL:ChristinMogaka@my.unt.edu	* *
 * ***************************************/

#include <vector>
#include "Movie.h"
#include <algorithm>
using namespace std;

class Movies
{
private:
    vector<Movie> movie_collection;

public:
    Movies();
    ~Movies();
    void search();
    Movie findOne(string id);
    void listOne();
    void add();
    void listAll();
    void remove();
    void printDetails(Movie mov);
    void update();
};
