/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING   * *
 * * CSCE 1040 –Homework 3              * *
 * * NAME:CHRISTINE MOGAKA              * *
 * * EUID:cm0981                        * *
 * * DATE:06/14/2021                    * *
 * * EMAIL:ChristineMogaka@my.unt.edu   * *
 * ***************************************/
#include "Loan.h"
#include <vector>

class Loans
{
private:
    vector<Loan> loans;

public:
    unsigned int count;
    Loans();
    ~Loans();
    void add(string movie_id, string customer_id, string date_due, float amount, string loan_id);
    void remove();
    void listOne();
    void listAll();
    void customerLoans();
    void movieLoans();
    void overDueLoans();
    void canceledLoans();
    void activeLoans();
    void completeLoans();
    void update();
    string getStr(string prompt);
};
