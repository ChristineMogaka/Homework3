/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING	* *
 * * CSCE 1040 –Homework 3       	* *
 * * NAME:CHRISTINE MOGAKA		* *
 * * EUID:cm0981			* *
 * * DATE:06/14/2021			* *
 * * EMAIL:ChristineMogaka@my.unt.edu	* *
 * ***************************************/
#include "Loans.h"

Loans::Loans()
{
}
void Loans::add(string movie_id, string customer_id, string date_due, float amount, string loan_id)
{
    unsigned int len0 = loans.size();
    Loan newLoan = Loan(movie_id, customer_id, date_due, amount, loan_id);
    this->loans.push_back(newLoan);
    unsigned int len1 = loans.size();
    if (len0 + 1 == len1)
    {
        puts("\n");
        cout << "Loan Added Successfully\n";
        puts("\n");
        this->count++;
    }
    else
    {
        cout << "Error adding Loan\n";
        puts("\n");
    }
}

void Loans::listAll()
{
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);

        loan.printDetails();
        puts("\n");
    }
}

void Loans::listOne()
{
    string loan_id = this->getStr("Loan ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getLoanID() == loan_id)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found for Loan ID: " << loan_id << endl;
        puts("\n");
    }
}
void Loans::update()
{
    string loan_id = this->getStr("Loan ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan *loan = &loans.at(i);
        if (loan->getLoanID() == loan_id)
        {
            loan->edit();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found for Loan ID: " << loan_id << endl;
        puts("\n");
    }
}

void Loans::remove()
{
    string id = this->getStr("Loan ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan tempObj = loans.at(i);
        if (tempObj.getLoanID() == id)
        {
            found = true;
            loans.erase(loans.begin() + i);
        }
    }

    if (found)
    {
        cout << "Loan Deleted Successfully" << endl;
    }
    else
    {
        cout << "Loan with ID " << id << " not Found!" << endl;
    }
}

void Loans::customerLoans()
{
    string customer_id = this->getStr("Customer ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getCustomerId() == customer_id)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found fo Customer ID: " << customer_id << endl;
        puts("\n");
    }
}

void Loans::movieLoans()
{
    string movie_id = this->getStr("Movie ID");
    bool found = false;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getMovieId() == movie_id)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Loan Found for Movie ID: " << movie_id << endl;
        puts("\n");
    }
}

void Loans::overDueLoans()
{
    bool found;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getStatus() == 0)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Overdue Loan Found: " << endl;
        puts("\n");
    }
}
void Loans::canceledLoans()
{
    bool found;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getStatus() == 1)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Canceled Loan Found: " << endl;
        puts("\n");
    }
}
void Loans::activeLoans()
{
    bool found;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getStatus() == 3)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Active Loan Found: " << endl;
    }
}
void Loans::completeLoans()
{
    bool found;
    for (size_t i = 0; i < loans.size(); i++)
    {
        Loan loan = loans.at(i);
        if (loan.getStatus() == 2)
        {
            loan.printDetails();
            found = true;
        }
    }

    if (!found)
    {
        cout << "No Complete Loan Found: " << endl;
    }
}
string Loans::getStr(string prompt)
{
    string str;
    printf("Enter %s : ", prompt.c_str());
    cin >> str;
    return str;
}
