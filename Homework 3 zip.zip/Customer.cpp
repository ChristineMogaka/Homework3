/******************************************
 * * NAME:CHRISTINE MOGAKA		* *
 * * EUID:cm0981			* *
 * * DATE:06/14/2021	 		* *
 * * EMAIL:ChristineMogaka@my.unt.edu   * *
 * * CSCE 1040 Homework 3               * *							* *
 * ***************************************/

#include "Customer.h"
#include <cmath>

// dummy constructor to fix bug
Customer::Customer(string dummy)
{
}

// initialization constructor
Customer::Customer()
{
    this->setName();
    this->setId();
    this->setCardNo();
    this->setCardKey();
    this->setCardExp();
    this->movie_count = 0;
}

Customer::~Customer()
{
}

// Utility Functions
void Customer::printDetails()
{
    printf("+--------------------------------------+\n");
    printf("| Name: %s\n", this->name.c_str());
    printf("| ID: %s\n", this->ID.c_str());
    printf("| Card No: %s\n", this->card_no.c_str());
    printf("| Card Key: %s\n", this->card_key.c_str());
    printf("| Card Expiry:%s\n", this->card_exp.c_str());
    printf("| Loaned Movie: %d\n", this->movie_count);
    printf("+--------------------------------------+\n");
}
string Customer::getStr(string prompt, unsigned int min = 0, unsigned int max = 0, unsigned short len = 10)
{
    string str;
    if (max != 0 && min != 0)
    {
        printf("Enter %s (Min- %d Max- %d ): ", prompt.c_str(), min, max);
        cin >> str;
        if (str.length() > max || str.length() < min)
        {
            return "Invalid Input";
        }
        return str;
    }

    if (len > 0)
    {
        printf("Enter %s (Length- %d ): ", prompt.c_str(), len);
        cin >> str;
        if (str.length() != len)
        {
            return "Invalid Input";
        }
        return str;
    }

    return "Invalid Input";
}
void Customer::edit()
{
    printf("+--------------------------------------+\n");
    printf("| Enter Option To Continue             |\n");
    printf("| 1 : Edit Name                        |\n");
    printf("| 2 : Edit ID                          |\n");
    printf("| 3 : Edit Card No.                    |\n");
    printf("| 4 : Edit Card Key.                   |\n");
    printf("| 5 : Edit Card Expiry Date.           |\n");
    printf("| 6 : Edit All                         |\n");
    printf("+--------------------------------------+\n");
    cout << "--->";
    unsigned int option;
    cin >> option;
    switch (option)
    {
    case 1:
        this->setName();
        break;
    case 2:
        this->setId();
        break;
    case 3:
        this->setCardNo();
        break;
    case 4:
        this->setCardKey();
        break;
    case 5:
        this->setCardExp();
        break;
    case 6:
        this->setName();
        this->setId();
        this->setCardNo();
        this->setCardKey();
        this->setCardExp();
        break;
    default:
        cout << "Invalid Option Chosen. No changes Made";
        break;
    }
}
//Accessor Methods
string Customer::getId()
{
    return this->ID;
}
string Customer::getCardNo()
{
    return this->card_no;
}
string Customer::getName()
{
    return this->name;
}
unsigned int Customer::getMovieCount()
{
    return this->movie_count;
}
string Customer::getCardKey()
{
    return this->card_key;
}
string Customer::getCardExp()
{
    return this->card_exp;
}

// Mutator Methods
void Customer::updateCount()
{
    if (this->movie_count < 2)
    {
        this->movie_count += 1;
    }
}
void Customer::setId()
{
    string ID = this->getStr("Customer ID", 4, 8, 0);
    if (ID != "Invalid Input")
    {
        this->ID = ID;
    }
    else
    {
        cout << "Invalid Input Detected. Change Ignored...\n";
    }
}
void Customer::setCardNo()
{
    string card_no = this->getStr("Credit Card No.", 0, 0, 16);
    if (card_no != "Invalid Input")
    {
        this->card_no = card_no;
    }
    else
    {
        cout << "Invalid Input Detected.\n";
    }
}
void Customer::setName()
{
    string name = this->getStr("Customer Name", 4, 40, 0);
    if (name != "Invalid Input")
    {
        this->name = name;
    }
    else
    {
        cout << "Invalid Input Detected.\n";
    }
}
void Customer::setMovieCount()
{
    int temp;
    cout << "Enter Count to Add: ";
    cin >> temp;

    if (temp >= -2 && temp <= 2)
    {
        this->movie_count += (int)temp;
        puts("Update Successful");
    }
    else
    {
        puts("Invalid Input");
    }
}
void Customer::setCardKey()
{
    string card_key = this->getStr("Card CCV", 3, 4, 0);
    if (card_key != "Invalid Input")
    {

        this->card_key = card_key;
    }
    else
    {
        cout << "Invalid Input Detected.\n";
    }
}
void Customer::setCardExp()
{
    string card_exp = this->getStr("Card Exp Date (mm/yyyy)", 0, 0, 7);
    if (card_exp != "Invalid Input")
    {

        this->card_exp = card_exp;
    }
    else
    {
        cout << "Invalid Input Detected.\n";
    }
}
