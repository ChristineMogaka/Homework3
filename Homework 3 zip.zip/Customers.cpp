/******************************************
 * * COMPUTER SCIENCE AND ENGINEERING   * *
 * * CSCE 1040 –Homework 3              * *
 * * NAME:CHRISTINE MOGAKA              * *
 * * EUID:cm0981                        * *
 * * DATE:06/14/2021                    * *
 * * EMAIL:ChristineMogaka@my.unt.edu   * *
 * ***************************************/
#include "Customers.h"

void Customers::add()
{
    int len0 = this->customers.size();
    Customer newCustomer = Customer();
    this->customers.push_back(newCustomer);
    int len1 = this->customers.size();

    if (len0 + 1 == len1)
    {
        puts("\n");
        cout << "Customer Added Successfully\n";
        this->count++;
    }
    else
    {
        cout << "Error adding Customer\n";
    }
}

void Customers::remove()
{
    string id;
    cout << " Enter Customer ID:";
    cin >> id;
    bool found = false;
    for (size_t i = 0; i < customers.size(); i++)
    {
        Customer tempObj = customers.at(i);
        if (tempObj.getId() == id)
        {
            found = true;
            customers.erase(customers.begin() + i);
        }
    }

    if (found)
    {
        cout << "Customer Deleted Successfully" << endl;
    }
    else
    {
        cout << "Customer with id " << id << " not Found!" << endl;
    }
}

void Customers::findOne()
{
    string id;
    cout << " Enter Customer ID:";
    cin >> id;
    bool found = false;
    for (size_t i = 0; i < this->customers.size(); i++)
    {
        Customer tempObj = this->customers.at(i);
        if (tempObj.getId() == id)
        {
            found = true;
            this->customers.at(i).printDetails();
            break;
        }
    }

    if (!found)
    {
        cout << "Customer with id " << id << " not Found!" << endl;
    }
}

void Customers::listAll()
{
    for (size_t i = 0; i < customers.size(); i++)
    {
        customers.at(i).printDetails();
    }
}

Customer Customers::search(string id)
{
    for (size_t i = 0; i < this->customers.size(); i++)
    {
        Customer tempObj = this->customers.at(i);
        if (tempObj.getId() == id)
        {
            return this->customers.at(i);
        }
    }

    Customer cus = Customer("");
    return cus;
}

void Customers::edit()
{
    string id;
    cout << " Enter Customer ID To Edit:";
    cin >> id;
    bool found = false;
    for (size_t i = 0; i < customers.size(); i++)
    {
        Customer *tempObj = &customers.at(i);
        if (tempObj->getId() == id)
        {
            found = true;
            tempObj->edit();
        }
    }

    if (found)
    {
        cout << "Customer Upadated Successfully\n"
             << endl;
    }
    else
    {
        cout << "Customer with id " << id << " not Found!" << endl;
    }
}
